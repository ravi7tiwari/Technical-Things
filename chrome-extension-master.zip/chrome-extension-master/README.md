chrome-extension
================

chrome extension



steps
1: Go to chrome 
2: chrome://extensions
3: enable developer mode
4 load unpack
5 reload ctrl + R
