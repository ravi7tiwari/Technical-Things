var lang = window.navigator.language;

$(function() {	
	$("#site-url").attr("href", "http://www.example.com/"+lang)
})